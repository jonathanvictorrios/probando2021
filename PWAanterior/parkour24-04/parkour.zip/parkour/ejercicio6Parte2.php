<?php include_once("./encabezado.php"); ?>
    <form id="EstadoProvincia" method="POST">
        <text class="text-dark">Provincia/Estado</text>
        <input class="text-dark" id="campoEstado" type="text">
        asdasdasd
        <div id="campoSugerencias">
            <ul class="list-group" >
                
            </ul>

        </div>
    </form>
<?php include_once("./footer.php"); ?>